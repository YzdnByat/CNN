import torch
import torch.nn as nn

class convnet(nn.Module):
    def __init__(self):
        super(convnet, self).__init__()

        # Update input channels from 1 → 3 (CIFAR-10 is RGB)
        self.layer1 = nn.Sequential(
            nn.Conv2d(3, 16, kernel_size=3, stride=1, padding=1),  # padding=1 keeps spatial size
            nn.BatchNorm2d(16),
            nn.ReLU(),
            nn.MaxPool2d(2, 2)  # Output: 16 x 16 x 16
        )
        self.layer2 = nn.Sequential(
            nn.Conv2d(16, 32, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(2, 2)  # Output: 32 x 8 x 8
        )

        # Calculate flattened size using CIFAR-10 image dimensions: [3 x 32 x 32]
        with torch.no_grad():
            dummy = torch.zeros(1, 3, 32, 32)  # 3 channels, 32x32 image
            dummy = self.layer1(dummy)
            dummy = self.layer2(dummy)
            self.flattened_size = dummy.view(1, -1).shape[1]
        print("Flattened size:", self.flattened_size)

        # Fully connected layer
        self.fc = nn.Linear(self.flattened_size, 10)  # 10 CIFAR-10 classes

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x


