import torch
import torchvision
import torchvision.transforms as transforms
from torch.utils.data import random_split
import numpy as np


batch_size = 128

train_dataset = torchvision.datasets.CIFAR10(root='./data',
                                             train=True,
                                             transform=transforms.Compose([
                                               transforms.RandomCrop(32, padding=4),
                                               transforms.RandomHorizontalFlip(),
                                               transforms.ToTensor(),
                                               transforms.Normalize((0.4914, 0.4822, 0.4465),
                                                                    (0.2023, 0.1994, 0.2010))
                                           ]),
                                             download=True
                                             )
test_dataset = torchvision.datasets.CIFAR10(root='./data',
                                            train=False,
                                            transform=transforms.Compose([
                                                transforms.ToTensor(),
                                                transforms.Normalize((0.4914, 0.4822, 0.4465),
                                                                     (0.2023, 0.1994, 0.2010))
                                            ]),
                                            download=True
                                            )

train_len = int(len(train_dataset)*0.80)
test_len = int(len(train_dataset)-train_len)
train_dataset, valid_dataset = random_split(
    train_dataset, [train_len, test_len],
    generator=torch.Generator().manual_seed(42)
)

train_loader = torch.utils.data.DataLoader(dataset=train_dataset,
                                           batch_size=batch_size,
                                           shuffle=True)
valid_loader = torch.utils.data.DataLoader(dataset=valid_dataset,
                                           batch_size=batch_size,
                                           shuffle=False)
test_loader = torch.utils.data.DataLoader(dataset=test_dataset,
                                          batch_size=batch_size,
                                          shuffle=False)


from collections import Counter
import torchvision
import matplotlib.pyplot as plt

# # Load dataset (train or test)
# cifar_train = torchvision.datasets.CIFAR10(root='./data', train=True, download=True)

# Get labels
labels = [label for _, label in train_dataset]

# Count how many times each label appears
label_counts = Counter(labels)

# Map to class names
classes = ['airplane', 'automobile', 'bird', 'cat', 'deer',
           'dog', 'frog', 'horse', 'ship', 'truck']
class_counts = {classes[i]: label_counts[i] for i in range(10)}

# Print
for cls, count in class_counts.items():
    print(f"{cls}: {count}")

# Plot
plt.figure(figsize=(8, 5))
plt.bar(class_counts.keys(), class_counts.values())
plt.xticks(rotation=45)
plt.title("CIFAR-10 Class Distribution (Training Set)")
plt.ylabel("Number of Images")
plt.tight_layout()
plt.grid(axis='y')
plt.show()


# CIFAR-10 classes
classes = ['airplane', 'automobile', 'bird', 'cat', 'deer',
           'dog', 'frog', 'horse', 'ship', 'truck']

# Define the transform
transform = transforms.Compose([
    transforms.ToTensor()
])

# Load the training set
trainset = torchvision.datasets.CIFAR10(root='./data', train=True,
                                        download=True, transform=transform)

# DataLoader not needed here since we're not batching
images_shown = {}
fig = plt.figure(figsize=(12, 6))

# Loop through dataset until we have one image per class
i = 0
for img, label in trainset:
    class_name = classes[label]
    if class_name not in images_shown:
        images_shown[class_name] = (img, class_name)
        ax = fig.add_subplot(2, 5, len(images_shown))
        img = img / 2 + 0.5  # unnormalize (if needed)
        npimg = img.numpy()
        ax.imshow(np.transpose(npimg, (1, 2, 0)))
        ax.set_title(class_name)
        ax.axis('off')
        if len(images_shown) == 10:
            break

plt.tight_layout()
plt.show()





