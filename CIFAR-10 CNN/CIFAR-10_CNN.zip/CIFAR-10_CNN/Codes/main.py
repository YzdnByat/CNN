import torchvision
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import numpy as np
import torch.optim
from torch.optim import Adam
from model_1 import *
from model_2 import *
from model_3 import *
from load_data import *
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns

# Params
num_epochs = 25
lr = 0.001
n_class = 10
patience = 5  # for early stopping
min_delta = 1e-4

# Device configuration
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

# Model
model = convnet_3().to(device)
# Loss Function
loss_fn = nn.CrossEntropyLoss()
# Optimizer
optimizer = torch.optim.Adam(model.parameters(), lr=lr)
# Scheduler
scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=2)

train_loss = []
valid_loss = []

best_val_loss = float('inf')
epochs_no_improve = 0

# Train
num_steps = len(train_loader)
for epochs in range(num_epochs):
    model.train()
    running_loss = 0.0
    for j, (imgs, lbls) in enumerate(train_loader):
        imgs, lbls = imgs.to(device), lbls.to(device)
        optimizer.zero_grad()
        out = model(imgs)
        loss = loss_fn(out, lbls)
        loss.backward()
        optimizer.step()
        running_loss += loss.item()
        if j % 50 == 0:
            print('Epoch: [{}/{}] | Step: [{}/{}] | Loss: {:.6f}'
                  .format(epochs+1, num_epochs, j+1, num_steps, loss.item()))
    train_loss.append(running_loss / num_steps)
    print('Epoch: [{}/{}] | Loss: {:.6f}'
          .format(epochs+1, num_epochs, loss.item()))

    model.eval()
    with torch.no_grad():
        correct = 0
        total = 0
        running_valid_loss = 0.0
        for imgs, lbls in valid_loader:
            imgs, lbls = imgs.to(device), lbls.to(device)
            out = model(imgs)
            loss_val = loss_fn(out, lbls)
            running_valid_loss += loss_val.item()
            predicted = torch.argmax(out, dim=1)
            correct += (predicted == lbls).sum().item()
            total += lbls.size(0)
        avg_val_loss = running_valid_loss / len(valid_loader)
        valid_loss.append(avg_val_loss)
        print('Valid Loss: {:.6f} | Acc: {:.4f}'.format(valid_loss[-1], correct / total))

        # Step the scheduler
        scheduler.step(avg_val_loss)

        # Early stopping
        if best_val_loss - avg_val_loss > min_delta:
            best_val_loss = avg_val_loss
            epochs_no_improve = 0
        else:
            epochs_no_improve += 1
            if epochs_no_improve >= patience:
                print("Early stopping triggered.")
                break

# Plot losses
plt.plot(range(1, len(train_loss)+1), train_loss, label='Train Loss')
plt.plot(range(1, len(valid_loss)+1), valid_loss, label='Validation Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Training vs Validation Loss')
plt.legend()
plt.grid(True)
plt.show()



# Predictions and true labels
all_preds = []
all_labels = []

model.eval()
with torch.no_grad():
    for imgs, lbls in test_loader:
        imgs = imgs.to(device)
        outputs = model(imgs)
        preds = torch.argmax(outputs, dim=1).cpu()
        all_preds.extend(preds.numpy())
        all_labels.extend(lbls.numpy())

# Classification Report
print(classification_report(all_labels, all_preds, target_names=classes))

# Confusion Matrix
cm = confusion_matrix(all_labels, all_preds)
plt.figure(figsize=(10, 8))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=classes, yticklabels=classes)
plt.xlabel('Predicted')
plt.ylabel('True')
plt.title('Confusion Matrix')
plt.show()

